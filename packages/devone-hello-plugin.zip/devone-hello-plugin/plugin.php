<?php
add_action('devone_footer', function(){ echo '<!-- DevOne Hello Plugin active -->'; });
?>
