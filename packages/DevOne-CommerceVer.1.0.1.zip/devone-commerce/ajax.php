<?php
header('Content-Type: application/json; charset=utf-8');
$root = realpath(__DIR__ . '/../../..');
if (!$root || !is_file($root . '/config.php')) { echo json_encode(array('success'=>false,'error'=>'DevOneCMS root not found.')); exit; }
require_once $root . '/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/hooks.php';
require_once $root . '/core/schema.php';
require_once $root . '/core/functions.php';
require_once $root . '/core/security.php';
if (is_file($root . '/core/mailer.php')) { require_once $root . '/core/mailer.php'; }
require_once __DIR__ . '/includes/commerce.php';

try {
    $payload = json_decode((string)file_get_contents('php://input'), true);
    if (!is_array($payload)) { throw new Exception('Invalid request.'); }
    $action = (string)($payload['dvc_action'] ?? $payload['action'] ?? 'test_checkout');
    if ($action === 'cart_totals') {
        $totals = dvc_cart_totals(isset($payload['cart']) && is_array($payload['cart']) ? $payload['cart'] : array());
        echo json_encode(array('success'=>true,'totals'=>$totals,'display'=>array('subtotal'=>dvc_money($totals['subtotal']),'tax'=>dvc_money($totals['tax']),'shipping'=>dvc_money($totals['shipping']),'total'=>dvc_money($totals['total']))));
        exit;
    }
    if ($action === 'stripe_create_intent') { echo json_encode(dvc_stripe_create_payment_intent($payload)); exit; }
    if ($action === 'stripe_finalize_order') { echo json_encode(dvc_stripe_finalize_order($payload)); exit; }
    if ($action === 'paypal_create_order') { echo json_encode(dvc_paypal_create_order($payload)); exit; }
    if ($action === 'paypal_capture_order') { echo json_encode(dvc_paypal_capture_order($payload)); exit; }
    echo json_encode(dvc_create_order($payload));
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(array('success'=>false,'error'=>$e->getMessage()));
}
