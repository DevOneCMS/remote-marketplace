# Changelog

## 1.0.1
- Added mobile accordion/card layout for Commerce product management.
- Improved admin product thumbnails and action button stacking on small screens.
- Kept desktop table layout unchanged.

## 1.0.0

Marketplace-ready release package.

- Added marketplace metadata.
- Added Developer One Inc. as author.
- Added plugin icon, banner, and screenshot assets.
- Kept Stripe and PayPal Test/Live gateway settings.
- Kept product types, variations, tax, shipping, cart modal, AJAX cart behavior, and accordion orders.
- Kept receipt email attempt after successful checkout.

## 0.3.0-alpha

- Added Stripe and PayPal gateway setup.
- Added Test/Sandbox and Live/Production environment toggle.
- Added Stripe Payment Element checkout.
- Added PayPal JS SDK checkout buttons.
- Added successful payment order creation and receipt email attempt.

## 0.2.1

- Added accordion order cards with full order details.

## 0.2.0

- Added product types, variations, shipping, tax, and checkout customer fields.

## 0.1.x

- Added product manager, shop page, cart modal, and test checkout foundation.
