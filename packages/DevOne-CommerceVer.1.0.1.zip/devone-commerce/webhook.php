<?php
header('Content-Type: application/json; charset=utf-8');
$root = realpath(__DIR__ . '/../../..');
if (!$root || !is_file($root . '/config.php')) { http_response_code(500); echo json_encode(array('success'=>false,'error'=>'DevOneCMS root not found.')); exit; }
require_once $root . '/config.php';
require_once $root . '/core/db.php';
require_once $root . '/core/hooks.php';
require_once $root . '/core/schema.php';
require_once $root . '/core/functions.php';
if (is_file($root . '/core/mailer.php')) { require_once $root . '/core/mailer.php'; }
require_once __DIR__ . '/includes/commerce.php';

function dvc_webhook_stripe_signature_ok($payload, $header, $secret) {
    if ($secret === '') { return true; }
    $parts = array();
    foreach (explode(',', (string)$header) as $piece) {
        $kv = explode('=', trim($piece), 2);
        if (count($kv) === 2) { $parts[$kv[0]][] = $kv[1]; }
    }
    $timestamp = $parts['t'][0] ?? '';
    $v1s = $parts['v1'] ?? array();
    if ($timestamp === '' || !$v1s) { return false; }
    $expected = hash_hmac('sha256', $timestamp . '.' . $payload, $secret);
    foreach ($v1s as $sig) { if (hash_equals($expected, $sig)) { return true; } }
    return false;
}

try {
    dvc_install();
    $raw = (string)file_get_contents('php://input');
    $stripeSig = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';
    if ($stripeSig !== '') {
        if (!dvc_webhook_stripe_signature_ok($raw, $stripeSig, dvc_stripe_webhook_secret())) {
            http_response_code(400);
            echo json_encode(array('success'=>false,'error'=>'Invalid Stripe webhook signature.'));
            exit;
        }
        $event = json_decode($raw, true);
        if (!is_array($event)) { throw new Exception('Invalid Stripe payload.'); }
        echo json_encode(array('success'=>true,'provider'=>'stripe','received'=>true,'type'=>$event['type'] ?? 'unknown'));
        exit;
    }

    $event = json_decode($raw, true);
    echo json_encode(array('success'=>true,'provider'=>'paypal_or_generic','received'=>true,'event_type'=>$event['event_type'] ?? ($event['type'] ?? 'unknown')));
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(array('success'=>false,'error'=>$e->getMessage()));
}
