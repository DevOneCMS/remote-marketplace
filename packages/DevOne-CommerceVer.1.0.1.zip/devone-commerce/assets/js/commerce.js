(function(){
  const key = 'devone_commerce_cart_v2';
  const cfg = window.DevOneCommerceConfig || {};
  let stripeInstance = null;
  let stripeElements = null;
  let stripeClientSecret = null;
  let paypalRendered = false;

  function read(){
    try { return JSON.parse(localStorage.getItem(key) || '[]'); }
    catch(e){ return []; }
  }

  function write(cart){
    localStorage.setItem(key, JSON.stringify(cart));
    render();
    refreshServerTotals();
  }

  function money(v){ return '$' + (Number(v || 0)).toFixed(2); }
  function count(cart){ return cart.reduce((s,i) => s + Number(i.qty || 1), 0); }
  function subtotal(cart){ return cart.reduce((s,i) => s + (Number(i.price || 0) * Number(i.qty || 1)), 0); }
  function shipping(cart){ return cart.reduce((s,i) => s + (Number(i.shipping || 0) * Number(i.qty || 1)), 0); }
  function tax(cart){ return subtotal(cart) * (Number(cfg.taxPercent || 0) / 100); }
  function total(cart){ return subtotal(cart) + shipping(cart) + tax(cart); }
  function escapeHtml(s){ return String(s).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
  function mode(){ return cfg.checkoutMode || 'test'; }
  function envLabel(){ return (cfg.paymentEnvironment === 'live') ? 'LIVE MODE' : 'TEST MODE'; }
  function hasStripe(){ return (mode() === 'stripe' || mode() === 'both') && !!cfg.stripePublishableKey; }
  function hasPayPal(){ return (mode() === 'paypal' || mode() === 'both') && !!cfg.paypalClientId; }

  function loadScript(src){
    return new Promise((resolve, reject) => {
      const existing = document.querySelector('script[src="'+src+'"]');
      if(existing){ existing.addEventListener('load', resolve); return resolve(); }
      const s = document.createElement('script');
      s.src = src;
      s.async = true;
      s.onload = resolve;
      s.onerror = () => reject(new Error('Could not load '+src));
      document.head.appendChild(s);
    });
  }

  function ensureModal(){
    if (document.querySelector('.dvc-cart-modal')) return;
    const modal = document.createElement('div');
    modal.className = 'dvc-cart-modal';
    modal.innerHTML = `
      <div class="dvc-cart-backdrop"></div>
      <aside class="dvc-cart-panel">
        <div class="dvc-cart-head"><h3>Your Cart</h3><button type="button" class="dvc-cart-close">Close</button></div>
        <div class="dvc-cart-items"></div>
        <div class="dvc-cart-summary">
          <div><span>Subtotal</span><strong data-dvc-subtotal>$0.00</strong></div>
          <div><span>Tax</span><strong data-dvc-tax>$0.00</strong></div>
          <div><span>Shipping</span><strong data-dvc-shipping>$0.00</strong></div>
          <div class="dvc-cart-total"><span>Total</span><strong data-dvc-total>$0.00</strong></div>
        </div>
        <form class="dvc-checkout-form">
          <h4>Customer Information</h4>
          <div class="dvc-checkout-grid">
            <input name="name" placeholder="Full name" required>
            <input name="email" type="email" placeholder="Receipt email" required>
            <input name="phone" placeholder="Phone number">
            <input name="address1" placeholder="Address line 1">
            <input name="address2" placeholder="Address line 2">
            <input name="city" placeholder="City">
            <input name="state" placeholder="State">
            <input name="postal" placeholder="Postal code">
            <input name="country" placeholder="Country" value="US">
          </div>
          <div class="dvc-gateway-mode-badge" data-dvc-env-badge>TEST MODE</div>
          <div class="dvc-gateway-row">
            <button class="dvc-cart-checkout dvc-test-checkout" type="submit">Test Checkout</button>
            <button class="dvc-cart-checkout dvc-stripe-start" type="button">Pay with Stripe</button>
            <div class="dvc-paypal-host"></div>
          </div>
          <div class="dvc-stripe-box">
            <div id="dvc-stripe-payment-element"></div>
            <button type="button" class="dvc-cart-checkout dvc-stripe-confirm">Confirm Stripe Payment</button>
          </div>
        </form>
        <div class="dvc-cart-message"></div>
      </aside>`;
    document.body.appendChild(modal);
    modal.querySelector('.dvc-cart-backdrop').addEventListener('click', closeCart);
    modal.querySelector('.dvc-cart-close').addEventListener('click', closeCart);
    modal.querySelector('.dvc-checkout-form').addEventListener('submit', testCheckout);
    modal.querySelector('.dvc-stripe-start').addEventListener('click', startStripe);
    modal.querySelector('.dvc-stripe-confirm').addEventListener('click', confirmStripe);
    document.addEventListener('keydown', function(e){ if(e.key === 'Escape') closeCart(); });
  }

  function gatewayVisibility(){
    const test = document.querySelector('.dvc-test-checkout');
    const stripe = document.querySelector('.dvc-stripe-start');
    const paypal = document.querySelector('.dvc-paypal-host');
    const badge = document.querySelector('[data-dvc-env-badge]');
    if(badge){
      badge.textContent = envLabel();
      badge.classList.toggle('live', cfg.paymentEnvironment === 'live');
    }
    if(test) test.style.display = (mode() === 'test' || !hasStripe() && !hasPayPal()) ? '' : 'none';
    if(stripe) stripe.style.display = hasStripe() ? '' : 'none';
    if(paypal) paypal.style.display = hasPayPal() ? '' : 'none';
  }

  function openCart(){
    ensure();
    const modal = document.querySelector('.dvc-cart-modal');
    if(modal) modal.classList.add('open');
    gatewayVisibility();
    renderPayPal();
    refreshServerTotals();
  }
  function closeCart(){ const modal = document.querySelector('.dvc-cart-modal'); if(modal) modal.classList.remove('open'); }

  function createCartButton(className){
    const btn = document.createElement('button');
    btn.className = className;
    btn.type = 'button';
    btn.setAttribute('aria-label', 'Open cart');
    btn.innerHTML = '<span class="dvc-cart-icon">🛒</span><span class="dvc-cart-label">Cart</span><b>0</b>';
    btn.addEventListener('click', openCart);
    return btn;
  }

  function placeNavCart(){
    let navBtn = document.querySelector('.dvc-nav-cart');
    const adminLink = document.querySelector('header .adminlink');
    const navContainer = document.querySelector('header .nav-container') || document.querySelector('header nav') || document.querySelector('header');
    if (!navBtn) navBtn = createCartButton('dvc-nav-cart');
    if (adminLink && adminLink.parentNode && adminLink.previousElementSibling !== navBtn) {
      adminLink.parentNode.insertBefore(navBtn, adminLink);
      return true;
    }
    if (!adminLink && navContainer && navBtn.parentNode !== navContainer) {
      navContainer.appendChild(navBtn);
      return true;
    }
    return !!navBtn.parentNode;
  }

  function ensureFallbackCart(){
    if (document.querySelector('.dvc-cart-floating')) return;
    const btn = createCartButton('dvc-cart-floating');
    document.body.appendChild(btn);
  }

  function ensure(){
    ensureModal();
    const placed = placeNavCart();
    if (!placed) ensureFallbackCart();
    gatewayVisibility();
  }

  function selectedVariation(addBtn){
    const card = addBtn.closest('[data-dvc-card]');
    const sel = card ? card.querySelector('.dvc-product-option') : null;
    return sel ? sel.value : '';
  }

  function add(data, variation){
    let cart = read();
    const keyId = String(data.id) + '::' + String(variation || '');
    let existing = cart.find(i => String(i.cartKey) === keyId);
    if (existing) {
      existing.qty = Number(existing.qty || 1) + 1;
    } else {
      cart.push({cartKey:keyId, id:data.id, name:data.name, price:Number(data.price || 0), image:data.image, type:data.type || 'physical', shipping:Number(data.shipping || 0), variation:variation || '', qty:1});
    }
    write(cart);
    openCart();
  }

  function render(){
    ensure();
    const cart = read();
    document.querySelectorAll('.dvc-nav-cart b, .dvc-cart-floating b').forEach(b => b.textContent = count(cart));
    const wrap = document.querySelector('.dvc-cart-items');
    if(!wrap) return;
    wrap.innerHTML = cart.length ? '' : '<p class="dvc-cart-empty">Your cart is empty.</p>';

    cart.forEach((item, idx) => {
      const row = document.createElement('div');
      row.className = 'dvc-cart-item';
      const variation = item.variation ? '<small>Option: '+escapeHtml(item.variation)+'</small>' : '';
      row.innerHTML = '<img src="'+escapeHtml(item.image||'')+'" alt=""><div><h4>'+escapeHtml(item.name||'Product')+'</h4>'+variation+'<p>'+money(item.price)+' each</p></div><div class="dvc-qty"><button type="button" data-dvc-dec="'+idx+'">-</button><span>'+Number(item.qty||1)+'</span><button type="button" data-dvc-inc="'+idx+'">+</button></div>';
      wrap.appendChild(row);
    });
    updateTotalsLocal();
  }

  function updateTotalsLocal(){
    const cart = read();
    const data = {
      subtotal: subtotal(cart),
      tax: tax(cart),
      shipping: shipping(cart),
      total: total(cart)
    };
    setTotalsDisplay(data);
  }

  function setTotalsDisplay(data){
    const map = {subtotal:'[data-dvc-subtotal]', tax:'[data-dvc-tax]', shipping:'[data-dvc-shipping]', total:'[data-dvc-total]'};
    Object.keys(map).forEach(k => {
      const el = document.querySelector(map[k]);
      if(el) el.textContent = money(data[k] || 0);
    });
  }

  function payloadFromForm(){
    const form = document.querySelector('.dvc-checkout-form');
    if(!form) return null;
    return {
      name: form.name.value,
      email: form.email.value,
      phone: form.phone.value,
      address1: form.address1.value,
      address2: form.address2.value,
      city: form.city.value,
      state: form.state.value,
      postal: form.postal.value,
      country: form.country.value,
      cart: read()
    };
  }

  function validatePayload(payload){
    const msg = document.querySelector('.dvc-cart-message');
    if(!payload.cart.length){ showMessage('Cart is empty.', false); return false; }
    if(!payload.name || !payload.email){ showMessage('Name and receipt email are required.', false); return false; }
    return true;
  }

  function post(action, payload){
    payload = payload || {};
    payload.dvc_action = action;
    return fetch(cfg.ajaxUrl || '/content/plugins/devone-commerce/ajax.php', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify(payload)
    }).then(r => r.json().then(j => { if(!r.ok || !j.success) throw new Error(j.error || 'Request failed'); return j; }));
  }

  function refreshServerTotals(){
    const cart = read();
    if(!cart.length){ updateTotalsLocal(); return; }
    post('cart_totals', {cart:cart}).then(data => {
      if(data && data.totals) setTotalsDisplay({subtotal:data.totals.subtotal, tax:data.totals.tax, shipping:data.totals.shipping, total:data.totals.total});
    }).catch(updateTotalsLocal);
  }

  function showMessage(html, success){
    const msg = document.querySelector('.dvc-cart-message');
    if(!msg) return;
    msg.innerHTML = html;
    msg.classList.add('show');
    msg.classList.toggle('success', !!success);
    msg.classList.toggle('error', !success);
  }

  function handleOrderSuccess(data, email){
    const receiptLine = data.receipt_sent ? '<br>Receipt sent to '+escapeHtml(email) : '<br><small>Order saved. Receipt email could not be sent by the server mail setup yet.</small>';
    showMessage('Payment successful.<br><strong>Order '+escapeHtml(data.order_number)+'</strong><br>Total '+escapeHtml(data.total)+receiptLine, true);
    write([]);
  }

  function testCheckout(e){
    e.preventDefault();
    const payload = payloadFromForm();
    if(!validatePayload(payload)) return;
    post('test_checkout', payload).then(data => handleOrderSuccess(data, payload.email)).catch(err => showMessage('Payment unsuccessful: '+escapeHtml(err.message), false));
  }

  function startStripe(){
    const payload = payloadFromForm();
    if(!validatePayload(payload)) return;
    if(!hasStripe()){ showMessage('Stripe is not configured yet in Commerce Settings.', false); return; }
    showMessage('Preparing secure Stripe payment form ('+envLabel()+')...', true);
    loadScript('https://js.stripe.com/v3/').then(() => {
      if(!window.Stripe) throw new Error('Stripe.js did not load.');
      stripeInstance = window.Stripe(cfg.stripePublishableKey);
      return post('stripe_create_intent', payload);
    }).then(data => {
      stripeClientSecret = data.client_secret;
      stripeElements = stripeInstance.elements({clientSecret: stripeClientSecret});
      const host = document.getElementById('dvc-stripe-payment-element');
      if(host) host.innerHTML = '';
      const country = (payload.country || 'US').slice(0,2).toUpperCase();
      const paymentElement = stripeElements.create('payment', {
        defaultValues: {
          billingDetails: {
            name: payload.name || '',
            email: payload.email || '',
            phone: payload.phone || '',
            address: {
              line1: payload.address1 || '',
              line2: payload.address2 || '',
              city: payload.city || '',
              state: payload.state || '',
              postal_code: payload.postal || '',
              country: country || 'US'
            }
          }
        }
      });
      paymentElement.mount('#dvc-stripe-payment-element');
      const box = document.querySelector('.dvc-stripe-box');
      if(box) box.classList.add('open');
      showMessage('Stripe form is ready. Enter payment details and confirm.', true);
    }).catch(err => showMessage('Stripe setup failed: '+escapeHtml(err.message), false));
  }

  function confirmStripe(){
    const payload = payloadFromForm();
    if(!validatePayload(payload)) return;
    if(!stripeInstance || !stripeElements || !stripeClientSecret){ showMessage('Start Stripe checkout first.', false); return; }
    stripeInstance.confirmPayment({elements: stripeElements, confirmParams: {return_url: window.location.href}, redirect: 'if_required'}).then(result => {
      if(result.error) throw new Error(result.error.message || 'Stripe payment failed.');
      const pi = result.paymentIntent;
      if(!pi || pi.status !== 'succeeded') throw new Error('Stripe payment did not succeed yet.');
      payload.payment_intent = pi.id;
      return post('stripe_finalize_order', payload);
    }).then(data => handleOrderSuccess(data, payload.email)).catch(err => showMessage('Payment unsuccessful: '+escapeHtml(err.message), false));
  }

  function renderPayPal(){
    if(!hasPayPal() || paypalRendered) return;
    const host = document.querySelector('.dvc-paypal-host');
    if(!host) return;
    const src = 'https://www.paypal.com/sdk/js?client-id=' + encodeURIComponent(cfg.paypalClientId) + '&currency=' + encodeURIComponent(cfg.currency || 'USD') + '&intent=capture';
    loadScript(src).then(() => {
      if(!window.paypal || !window.paypal.Buttons) throw new Error('PayPal SDK did not load.');
      host.innerHTML = '';
      window.paypal.Buttons({
        createOrder: function(){
          const payload = payloadFromForm();
          if(!validatePayload(payload)) return Promise.reject(new Error('Missing checkout information.'));
          return post('paypal_create_order', payload).then(data => data.id);
        },
        onApprove: function(data){
          const payload = payloadFromForm();
          payload.order_id = data.orderID;
          return post('paypal_capture_order', payload).then(result => handleOrderSuccess(result, payload.email)).catch(err => showMessage('Payment unsuccessful: '+escapeHtml(err.message), false));
        },
        onError: function(err){ showMessage('PayPal error: '+escapeHtml(err && err.message ? err.message : err), false); }
      }).render(host);
      paypalRendered = true;
      const badge = document.querySelector('[data-dvc-env-badge]');
      if(badge){ badge.textContent = envLabel(); }
    }).catch(err => showMessage('PayPal setup failed: '+escapeHtml(err.message), false));
  }

  document.addEventListener('click', function(e){
    const addBtn = e.target.closest('.dvc-add-to-cart');
    if(addBtn){ add(addBtn.dataset, selectedVariation(addBtn)); }

    const inc = e.target.closest('[data-dvc-inc]');
    if(inc){
      let c = read();
      let i = Number(inc.dataset.dvcInc);
      if(c[i]) c[i].qty = Number(c[i].qty || 1) + 1;
      write(c);
    }

    const dec = e.target.closest('[data-dvc-dec]');
    if(dec){
      let c = read();
      let i = Number(dec.dataset.dvcDec);
      if(c[i]){
        c[i].qty = Number(c[i].qty || 1) - 1;
        if(c[i].qty <= 0) c.splice(i, 1);
      }
      write(c);
    }
  });

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', render);
  else render();

  document.addEventListener('devone:ready', render);
  window.DevOneCommerce = window.DevOneCommerce || {};
  window.DevOneCommerce.openCart = openCart;
  window.DevOneCommerce.renderCart = render;
})();
