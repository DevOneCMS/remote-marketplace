<?php
if (!defined('DVC_PLUGIN_SLUG')) { define('DVC_PLUGIN_SLUG', 'devone-commerce'); }
if (!defined('DVC_PLUGIN_DIR')) { define('DVC_PLUGIN_DIR', dirname(__DIR__)); }
if (!defined('DVC_PLUGIN_FOLDER')) { define('DVC_PLUGIN_FOLDER', basename(DVC_PLUGIN_DIR)); }
if (!defined('DVC_PLUGIN_URL')) {
    $folder = preg_replace('/[^a-zA-Z0-9_\-]/', '', DVC_PLUGIN_FOLDER);
    $base = function_exists('devone_site_url') ? rtrim(devone_site_url('content/plugins/' . $folder), '/') : '../content/plugins/' . $folder;
    define('DVC_PLUGIN_URL', $base);
}

function dvc_table($name) {
    return function_exists('table_name') ? table_name('commerce_' . preg_replace('/[^a-zA-Z0-9_]/', '', $name)) : 'cms_commerce_' . $name;
}

function dvc_money($amount) {
    $currency = strtoupper((string)dvc_setting('currency', 'USD'));
    $symbol = $currency === 'USD' ? '$' : $currency . ' ';
    return $symbol . number_format((float)$amount, 2);
}

function dvc_slug($value, $fallback = 'item') {
    if (function_exists('devone_slugify')) { return devone_slugify($value, $fallback); }
    $slug = trim(preg_replace('/[^a-z0-9\-_]+/', '-', strtolower((string)$value)), '-');
    return $slug !== '' ? $slug : $fallback;
}

function dvc_column_exists($table, $column) {
    try {
        $stmt = db()->prepare("SHOW COLUMNS FROM `{$table}` LIKE ?");
        $stmt->execute(array($column));
        return (bool)$stmt->fetch();
    } catch (Throwable $e) { return false; }
}

function dvc_add_column($table, $column, $definition) {
    try {
        if (!dvc_column_exists($table, $column)) { db()->exec("ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}"); }
    } catch (Throwable $e) {}
}

function dvc_setting($key, $default = '') {
    try {
        dvc_install();
        $stmt = db()->prepare('SELECT setting_value FROM `' . dvc_table('settings') . '` WHERE setting_key=? LIMIT 1');
        $stmt->execute(array($key));
        $value = $stmt->fetchColumn();
        return $value === false ? $default : $value;
    } catch (Throwable $e) { return $default; }
}

function dvc_set_setting($key, $value) {
    dvc_install();
    $stmt = db()->prepare('INSERT INTO `' . dvc_table('settings') . '` (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)');
    return $stmt->execute(array($key, $value));
}

function dvc_install() {
    static $done = false;
    if ($done || !function_exists('db')) { return; }
    $done = true;

    $products = dvc_table('products');
    $orders = dvc_table('orders');
    $items = dvc_table('order_items');
    $settings = dvc_table('settings');

    db()->exec("CREATE TABLE IF NOT EXISTS `{$products}` (
        `id` int NOT NULL AUTO_INCREMENT,
        `name` varchar(255) NOT NULL,
        `slug` varchar(255) NOT NULL,
        `sku` varchar(120) DEFAULT '',
        `product_type` varchar(40) DEFAULT 'physical',
        `variations` text,
        `download_url` varchar(1000) DEFAULT '',
        `service_note` varchar(500) DEFAULT '',
        `shipping_price` decimal(12,2) DEFAULT 0.00,
        `price` decimal(12,2) NOT NULL DEFAULT 0.00,
        `sale_price` decimal(12,2) DEFAULT NULL,
        `image` varchar(1000) DEFAULT '',
        `short_description` text,
        `description` longtext,
        `status` varchar(30) DEFAULT 'published',
        `stock` int DEFAULT 999,
        `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
        `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `slug` (`slug`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    db()->exec("CREATE TABLE IF NOT EXISTS `{$orders}` (
        `id` bigint NOT NULL AUTO_INCREMENT,
        `order_number` varchar(80) NOT NULL,
        `customer_name` varchar(255) DEFAULT '',
        `customer_email` varchar(255) DEFAULT '',
        `customer_phone` varchar(80) DEFAULT '',
        `billing_address` text,
        `status` varchar(40) DEFAULT 'pending',
        `gateway` varchar(40) DEFAULT 'test',
        `subtotal` decimal(12,2) DEFAULT 0.00,
        `tax_amount` decimal(12,2) DEFAULT 0.00,
        `shipping_amount` decimal(12,2) DEFAULT 0.00,
        `total` decimal(12,2) DEFAULT 0.00,
        `cart_json` longtext,
        `payment_reference` varchar(255) DEFAULT '',
        `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `order_number` (`order_number`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    db()->exec("CREATE TABLE IF NOT EXISTS `{$items}` (
        `id` bigint NOT NULL AUTO_INCREMENT,
        `order_id` bigint NOT NULL,
        `product_id` int DEFAULT NULL,
        `product_name` varchar(255) NOT NULL,
        `variation` varchar(255) DEFAULT '',
        `product_type` varchar(40) DEFAULT '',
        `quantity` int DEFAULT 1,
        `price` decimal(12,2) DEFAULT 0.00,
        `line_total` decimal(12,2) DEFAULT 0.00,
        PRIMARY KEY (`id`),
        KEY `order_id` (`order_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    db()->exec("CREATE TABLE IF NOT EXISTS `{$settings}` (
        `id` int NOT NULL AUTO_INCREMENT,
        `setting_key` varchar(160) NOT NULL,
        `setting_value` longtext,
        PRIMARY KEY (`id`),
        UNIQUE KEY `setting_key` (`setting_key`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    dvc_add_column($products, 'product_type', "varchar(40) DEFAULT 'physical'");
    dvc_add_column($products, 'variations', 'text');
    dvc_add_column($products, 'download_url', "varchar(1000) DEFAULT ''");
    dvc_add_column($products, 'service_note', "varchar(500) DEFAULT ''");
    dvc_add_column($products, 'shipping_price', 'decimal(12,2) DEFAULT 0.00');

    dvc_add_column($orders, 'customer_phone', "varchar(80) DEFAULT ''");
    dvc_add_column($orders, 'billing_address', 'text');
    dvc_add_column($orders, 'tax_amount', 'decimal(12,2) DEFAULT 0.00');
    dvc_add_column($orders, 'shipping_amount', 'decimal(12,2) DEFAULT 0.00');

    dvc_add_column($items, 'variation', "varchar(255) DEFAULT ''");
    dvc_add_column($items, 'product_type', "varchar(40) DEFAULT ''");

    dvc_seed_settings();
    dvc_seed_products();
    dvc_seed_shop_page();
}

function dvc_seed_settings() {
    $defaults = array(
        'store_name' => 'DevOne Commerce Demo Shop',
        'currency' => 'USD',
        'tax_percent' => '0',
        'gateway_mode' => 'test',
        'payment_environment' => 'test',
        'enabled_gateways' => 'test',

        // Legacy / fallback keys from earlier alpha builds.
        'stripe_publishable_key' => '',
        'stripe_secret_key' => '',
        'stripe_webhook_secret' => '',
        'paypal_client_id' => '',
        'paypal_secret' => '',
        'paypal_webhook_id' => '',
        'paypal_environment' => 'sandbox',

        // Stripe mode-specific keys.
        'stripe_test_publishable_key' => '',
        'stripe_test_secret_key' => '',
        'stripe_test_webhook_secret' => '',
        'stripe_live_publishable_key' => '',
        'stripe_live_secret_key' => '',
        'stripe_live_webhook_secret' => '',

        // PayPal mode-specific keys.
        'paypal_sandbox_client_id' => '',
        'paypal_sandbox_secret' => '',
        'paypal_sandbox_webhook_id' => '',
        'paypal_live_client_id' => '',
        'paypal_live_secret' => '',
        'paypal_live_webhook_id' => '',
    );
    foreach ($defaults as $k => $v) {
        try {
            $stmt = db()->prepare('INSERT IGNORE INTO `' . dvc_table('settings') . '` (setting_key, setting_value) VALUES (?, ?)');
            $stmt->execute(array($k, $v));
        } catch (Throwable $e) {}
    }
}

function dvc_seed_products() {
    try {
        $count = (int)db()->query('SELECT COUNT(*) FROM `' . dvc_table('products') . '`')->fetchColumn();
        if ($count > 0) { return; }
        $products = array(
            array('Premium Beat Pack', 'premium-beat-pack', 'DVC-BEATS-001', 'digital', 'MP3,WAV,Trackouts', 29.99, 0.00, 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?auto=format&fit=crop&w=900&q=80', 'A starter pack of polished demo beats for testing a digital music store.', 'Includes trap drums, R&B melodies, pop loops, and licensing demo text.'),
            array('Artist Merch Hoodie', 'artist-merch-hoodie', 'DVC-HOODIE-001', 'physical', 'Small,Medium,Large,XL,2XL', 54.99, 7.99, 'https://images.unsplash.com/photo-1523398002811-999ca8dec234?auto=format&fit=crop&w=900&q=80', 'A bold premium hoodie product card for testing physical product layouts.', 'Use this product to test variations, shipping, quantities, pricing, and checkout flow.'),
            array('Sample Kit Bundle', 'sample-kit-bundle', 'DVC-SAMPLES-001', 'digital', 'Standard License,Premium License', 19.99, 0.00, 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?auto=format&fit=crop&w=900&q=80', 'A digital sample kit with drums, synths, FX, and vocal chops.', 'A perfect demo product for testing digital goods and downloadable products.'),
            array('VIP Show Pass', 'vip-show-pass', 'DVC-VIP-001', 'service', 'General Admission,VIP,Backstage', 99.00, 0.00, 'https://images.unsplash.com/photo-1507874457470-272b3c8d8ee2?auto=format&fit=crop&w=900&q=80', 'A VIP pass style product for music events and artist experiences.', 'Use this item to test service/event style sales pages.'),
        );
        $stmt = db()->prepare('INSERT INTO `' . dvc_table('products') . '` (name,slug,sku,product_type,variations,price,shipping_price,image,short_description,description,status,stock) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
        foreach ($products as $p) { $stmt->execute(array($p[0],$p[1],$p[2],$p[3],$p[4],$p[5],$p[6],$p[7],$p[8],$p[9],'published',100)); }
    } catch (Throwable $e) {}
}

function dvc_seed_shop_page() {
    if (!function_exists('table_exists') || !table_exists('pages')) { return; }
    try {
        $pages = table_name('pages');
        $check = db()->prepare('SELECT id FROM `' . $pages . '` WHERE slug=? LIMIT 1');
        $check->execute(array('shop'));
        if ($check->fetchColumn()) { return; }
        $content = '<section class="devone-boxed-content"><h1>Shop</h1><p>Browse demo products powered by DevOne Commerce.</p></section>[devone_shop]';
        $stmt = db()->prepare('INSERT INTO `' . $pages . '` (slug,title,content,status,template) VALUES (?,?,?,?,?)');
        $stmt->execute(array('shop','Shop',$content,'published','default'));
    } catch (Throwable $e) {}
}

function dvc_products($publishedOnly = true) {
    dvc_install();
    $sql = 'SELECT * FROM `' . dvc_table('products') . '`';
    if ($publishedOnly) { $sql .= " WHERE status='published'"; }
    $sql .= ' ORDER BY id DESC';
    try { return db()->query($sql)->fetchAll(); }
    catch (Throwable $e) { return array(); }
}

function dvc_product($id) {
    dvc_install();
    $stmt = db()->prepare('SELECT * FROM `' . dvc_table('products') . '` WHERE id=? LIMIT 1');
    $stmt->execute(array((int)$id));
    return $stmt->fetch() ?: null;
}

function dvc_variation_list($value) {
    $out = array();
    foreach (explode(',', (string)$value) as $v) {
        $v = trim($v);
        if ($v !== '') { $out[] = $v; }
    }
    return $out;
}

function dvc_render_shop() {
    $products = dvc_products(true);
    ob_start();
    ?>
    <section class="dvc-shop-wrap devone-full-bleed alignfull">
      <div class="dvc-shop-hero">
        <span>DevOne Commerce v1.0.0</span>
        <h2>Products that stay on your site.</h2>
        <p>This is a plugin-powered shop page with product types, variations, tax, shipping, cart modal, test checkout, Stripe, PayPal, and test/live gateway toggles.</p>
      </div>
      <div class="dvc-product-grid">
        <?php foreach ($products as $p):
            $price = $p['sale_price'] !== null && $p['sale_price'] !== '' ? (float)$p['sale_price'] : (float)$p['price'];
            $vars = dvc_variation_list($p['variations'] ?? '');
            $type = $p['product_type'] ?? 'physical';
        ?>
          <article class="dvc-product-card" data-dvc-card>
            <img src="<?= e($p['image'] ?? '') ?>" alt="<?= e($p['name'] ?? 'Product') ?>">
            <div class="dvc-product-body">
              <small><?= e($p['sku'] ?? 'DVC') ?> · <?= e(ucfirst($type)) ?></small>
              <h3><?= e($p['name'] ?? '') ?></h3>
              <p><?= e($p['short_description'] ?? '') ?></p>
              <?php if ($vars): ?>
                <label class="dvc-product-option-label">Option
                  <select class="dvc-product-option">
                    <?php foreach ($vars as $v): ?><option value="<?= e($v) ?>"><?= e($v) ?></option><?php endforeach; ?>
                  </select>
                </label>
              <?php endif; ?>
              <div class="dvc-product-actions">
                <strong><?= e(dvc_money($price)) ?></strong>
                <button class="dvc-add-to-cart" type="button"
                  data-id="<?= (int)$p['id'] ?>"
                  data-name="<?= e($p['name'] ?? '') ?>"
                  data-price="<?= e((string)$price) ?>"
                  data-image="<?= e($p['image'] ?? '') ?>"
                  data-type="<?= e($type) ?>"
                  data-shipping="<?= e((string)($p['shipping_price'] ?? '0')) ?>">Add to Cart</button>
              </div>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    </section>
    <?php
    return ob_get_clean();
}

function dvc_replace_shortcodes($content) {
    if (strpos($content, '[devone_shop]') !== false) { $content = str_replace('[devone_shop]', dvc_render_shop(), $content); }
    return $content;
}

function dvc_head_assets() {
    echo "\n<link rel=\"stylesheet\" href=\"" . e(DVC_PLUGIN_URL . '/assets/css/commerce.css?v=1.0.0') . "\">\n";
}

function dvc_gateway_mode() {
    $mode = dvc_setting('gateway_mode','test');
    return in_array($mode, array('test','stripe','paypal','both'), true) ? $mode : 'test';
}

function dvc_payment_environment() {
    $env = dvc_setting('payment_environment', dvc_setting('paypal_environment','sandbox') === 'live' ? 'live' : 'test');
    return $env === 'live' ? 'live' : 'test';
}

function dvc_stripe_publishable_key() {
    if (dvc_payment_environment() === 'live') {
        return trim((string)dvc_setting('stripe_live_publishable_key', dvc_setting('stripe_publishable_key','')));
    }
    return trim((string)dvc_setting('stripe_test_publishable_key', dvc_setting('stripe_publishable_key','')));
}

function dvc_stripe_secret_key() {
    if (dvc_payment_environment() === 'live') {
        return trim((string)dvc_setting('stripe_live_secret_key', dvc_setting('stripe_secret_key','')));
    }
    return trim((string)dvc_setting('stripe_test_secret_key', dvc_setting('stripe_secret_key','')));
}

function dvc_stripe_webhook_secret() {
    if (dvc_payment_environment() === 'live') {
        return trim((string)dvc_setting('stripe_live_webhook_secret', dvc_setting('stripe_webhook_secret','')));
    }
    return trim((string)dvc_setting('stripe_test_webhook_secret', dvc_setting('stripe_webhook_secret','')));
}

function dvc_paypal_environment() {
    return dvc_payment_environment() === 'live' ? 'live' : 'sandbox';
}

function dvc_paypal_client_id() {
    if (dvc_paypal_environment() === 'live') {
        return trim((string)dvc_setting('paypal_live_client_id', dvc_setting('paypal_client_id','')));
    }
    return trim((string)dvc_setting('paypal_sandbox_client_id', dvc_setting('paypal_client_id','')));
}

function dvc_paypal_secret() {
    if (dvc_paypal_environment() === 'live') {
        return trim((string)dvc_setting('paypal_live_secret', dvc_setting('paypal_secret','')));
    }
    return trim((string)dvc_setting('paypal_sandbox_secret', dvc_setting('paypal_secret','')));
}

function dvc_paypal_webhook_id() {
    if (dvc_paypal_environment() === 'live') {
        return trim((string)dvc_setting('paypal_live_webhook_id', dvc_setting('paypal_webhook_id','')));
    }
    return trim((string)dvc_setting('paypal_sandbox_webhook_id', dvc_setting('paypal_webhook_id','')));
}

function dvc_stripe_amount_from_total($total, $currency) {
    $zeroDecimal = array('BIF','CLP','DJF','GNF','JPY','KMF','KRW','MGA','PYG','RWF','UGX','VND','VUV','XAF','XOF','XPF');
    $currency = strtoupper((string)$currency);
    return in_array($currency, $zeroDecimal, true) ? (int)round((float)$total) : (int)round(((float)$total) * 100);
}

function dvc_footer_assets() {
    $ajax = DVC_PLUGIN_URL . '/ajax.php';
    $cfg = array(
        'ajaxUrl' => $ajax,
        'checkoutMode' => dvc_gateway_mode(),
        'paymentEnvironment' => dvc_payment_environment(),
        'currency' => strtoupper((string)dvc_setting('currency','USD')),
        'taxPercent' => (float)dvc_setting('tax_percent','0'),
        'stripePublishableKey' => dvc_stripe_publishable_key(),
        'paypalClientId' => dvc_paypal_client_id(),
        'paypalEnvironment' => dvc_paypal_environment(),
    );
    echo "
<script>window.DevOneCommerceConfig=" . json_encode($cfg) . ";</script>
";
    echo "<script src=\"" . e(DVC_PLUGIN_URL . '/assets/js/commerce.js?v=1.0.0') . "\"></script>\n";
}

function dvc_cart_totals($cart) {
    dvc_install();
    $subtotal = 0.0;
    $shipping = 0.0;
    $normalized = array();
    foreach ($cart as $item) {
        $id = (int)($item['id'] ?? 0);
        $qty = max(1, (int)($item['qty'] ?? 1));
        $product = $id > 0 ? dvc_product($id) : null;
        if (!$product) { continue; }
        $price = $product['sale_price'] !== null && $product['sale_price'] !== '' ? (float)$product['sale_price'] : (float)$product['price'];
        $type = $product['product_type'] ?: 'physical';
        $variation = trim((string)($item['variation'] ?? ''));
        $line = $qty * $price;
        $shipLine = $type === 'physical' ? ($qty * (float)($product['shipping_price'] ?? 0)) : 0.0;
        $subtotal += $line;
        $shipping += $shipLine;
        $normalized[] = array(
            'id' => (int)$product['id'],
            'name' => (string)$product['name'],
            'variation' => $variation,
            'type' => $type,
            'qty' => $qty,
            'price' => $price,
            'shipping' => $shipLine,
            'line_total' => $line,
            'image' => (string)($product['image'] ?? ''),
        );
    }
    if (!$normalized) { throw new Exception('Cart does not contain valid products.'); }
    $taxPercent = max(0, (float)dvc_setting('tax_percent','0'));
    $tax = round($subtotal * ($taxPercent / 100), 2);
    $total = round($subtotal + $tax + $shipping, 2);
    return array('items'=>$normalized, 'subtotal'=>round($subtotal,2), 'tax'=>$tax, 'shipping'=>round($shipping,2), 'total'=>$total, 'tax_percent'=>$taxPercent);
}

function dvc_order_items_html($cart) {
    $rows = '';
    foreach ($cart as $item) {
        $qty = max(1, (int)($item['qty'] ?? 1));
        $price = (float)($item['price'] ?? 0);
        $name = htmlspecialchars((string)($item['name'] ?? 'Product'), ENT_QUOTES, 'UTF-8');
        $variation = trim((string)($item['variation'] ?? ''));
        if ($variation !== '') { $name .= ' <br><small>Option: ' . htmlspecialchars($variation, ENT_QUOTES, 'UTF-8') . '</small>'; }
        $line = dvc_money($qty * $price);
        $rows .= '<tr><td style="padding:10px;border-bottom:1px solid rgba(255,255,255,.08);">' . $name . '</td><td style="padding:10px;border-bottom:1px solid rgba(255,255,255,.08);text-align:center;">' . $qty . '</td><td style="padding:10px;border-bottom:1px solid rgba(255,255,255,.08);text-align:right;">' . htmlspecialchars($line, ENT_QUOTES, 'UTF-8') . '</td></tr>';
    }
    return '<table style="width:100%;border-collapse:collapse;margin:16px 0;"><thead><tr><th style="padding:10px;text-align:left;">Item</th><th style="padding:10px;text-align:center;">Qty</th><th style="padding:10px;text-align:right;">Total</th></tr></thead><tbody>' . $rows . '</tbody></table>';
}

function dvc_send_order_receipt($email, $name, $orderNumber, $cart, $totals, $gateway) {
    $email = trim((string)$email);
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) { return array('ok'=>false, 'message'=>'No valid receipt email.'); }
    $safeName = htmlspecialchars($name !== '' ? $name : 'Customer', ENT_QUOTES, 'UTF-8');
    $safeOrder = htmlspecialchars($orderNumber, ENT_QUOTES, 'UTF-8');
    $storeName = htmlspecialchars(dvc_setting('store_name', 'DevOne Commerce'), ENT_QUOTES, 'UTF-8');
    $body = '<p>Hi <strong>' . $safeName . '</strong>,</p>' .
        '<p>Thank you for your order from <strong>' . $storeName . '</strong>.</p>' .
        '<p><strong>Order:</strong> ' . $safeOrder . '<br><strong>Status:</strong> Payment confirmed<br><strong>Gateway:</strong> ' . htmlspecialchars($gateway, ENT_QUOTES, 'UTF-8') . '<br><strong>Total:</strong> ' . htmlspecialchars(dvc_money($totals['total']), ENT_QUOTES, 'UTF-8') . '</p>' .
        dvc_order_items_html($cart) .
        '<p><strong>Subtotal:</strong> ' . htmlspecialchars(dvc_money($totals['subtotal']), ENT_QUOTES, 'UTF-8') . '<br><strong>Tax:</strong> ' . htmlspecialchars(dvc_money($totals['tax']), ENT_QUOTES, 'UTF-8') . '<br><strong>Shipping:</strong> ' . htmlspecialchars(dvc_money($totals['shipping']), ENT_QUOTES, 'UTF-8') . '</p>';
    if (function_exists('devone_send_email')) {
        return devone_send_email($email, 'Receipt for order ' . $orderNumber, $body);
    }
    return array('ok'=>false, 'message'=>'DevOne mail helper is not loaded.');
}

function dvc_customer_from_payload($payload) {
    $name = trim((string)($payload['name'] ?? 'Guest Customer'));
    $email = trim((string)($payload['email'] ?? ''));
    $phone = trim((string)($payload['phone'] ?? ''));
    $addressParts = array(
        trim((string)($payload['address1'] ?? '')),
        trim((string)($payload['address2'] ?? '')),
        trim((string)($payload['city'] ?? '')),
        trim((string)($payload['state'] ?? '')),
        trim((string)($payload['postal'] ?? '')),
        trim((string)($payload['country'] ?? '')),
    );
    $address = trim(implode("\n", array_filter($addressParts)));
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) { throw new Exception('A valid email is required so DevOne Commerce can send the receipt.'); }
    return array('name'=>$name, 'email'=>$email, 'phone'=>$phone, 'address'=>$address);
}

function dvc_create_order_record($payload, $gateway, $status, $reference) {
    dvc_install();
    $customer = dvc_customer_from_payload($payload);
    $cart = isset($payload['cart']) && is_array($payload['cart']) ? $payload['cart'] : array();
    if (!$cart) { throw new Exception('Cart is empty.'); }
    $totals = dvc_cart_totals($cart);
    $orderNumber = 'DVC-' . date('Ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
    $stmt = db()->prepare('INSERT INTO `' . dvc_table('orders') . '` (order_number,customer_name,customer_email,customer_phone,billing_address,status,gateway,subtotal,tax_amount,shipping_amount,total,cart_json,payment_reference) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)');
    $stmt->execute(array($orderNumber,$customer['name'],$customer['email'],$customer['phone'],$customer['address'],$status,$gateway,$totals['subtotal'],$totals['tax'],$totals['shipping'],$totals['total'],json_encode($totals['items']),$reference));
    $orderId = (int)db()->lastInsertId();
    $itemStmt = db()->prepare('INSERT INTO `' . dvc_table('order_items') . '` (order_id,product_id,product_name,variation,product_type,quantity,price,line_total) VALUES (?,?,?,?,?,?,?,?)');
    foreach ($totals['items'] as $item) {
        $itemStmt->execute(array($orderId, (int)$item['id'], (string)$item['name'], (string)$item['variation'], (string)$item['type'], (int)$item['qty'], (float)$item['price'], (float)$item['line_total']));
    }
    $receipt = dvc_send_order_receipt($customer['email'], $customer['name'], $orderNumber, $totals['items'], $totals, $gateway);
    return array('success'=>true, 'order_number'=>$orderNumber, 'status'=>'confirmed', 'gateway'=>$gateway, 'total'=>dvc_money($totals['total']), 'totals'=>$totals, 'receipt_sent'=>!empty($receipt['ok']), 'receipt_message'=>$receipt['message'] ?? '');
}

function dvc_create_order($payload) {
    return dvc_create_order_record($payload, 'test', 'paid-test', 'TEST-' . time());
}

function dvc_http_post($url, $headers, $body, $auth = null) {
    if (!function_exists('curl_init')) { throw new Exception('PHP cURL extension is required for live payment gateways.'); }
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    if ($auth) { curl_setopt($ch, CURLOPT_USERPWD, $auth); }
    $raw = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($raw === false) { throw new Exception($err ?: 'HTTP request failed.'); }
    $json = json_decode($raw, true);
    if ($code >= 400) { throw new Exception('Gateway HTTP error ' . $code . ': ' . ($json['error']['message'] ?? $json['message'] ?? $raw)); }
    return is_array($json) ? $json : array('raw'=>$raw);
}

function dvc_stripe_request($path, $params = array()) {
    $secret = dvc_stripe_secret_key();
    if ($secret === '') { throw new Exception('Stripe Secret Key is missing in Commerce Settings.'); }
    return dvc_http_post('https://api.stripe.com/v1/' . ltrim($path, '/'), array('Content-Type: application/x-www-form-urlencoded'), http_build_query($params), $secret . ':');
}

function dvc_stripe_create_payment_intent($payload) {
    $cart = isset($payload['cart']) && is_array($payload['cart']) ? $payload['cart'] : array();
    if (!$cart) { throw new Exception('Cart is empty.'); }
    $customer = dvc_customer_from_payload($payload);
    $totals = dvc_cart_totals($cart);
    $currency = strtolower((string)dvc_setting('currency','USD'));
    $amount = dvc_stripe_amount_from_total($totals['total'], $currency);
    if ($amount < 50) { throw new Exception('Stripe payment amount is too low.'); }
    $pi = dvc_stripe_request('payment_intents', array(
        'amount' => $amount,
        'currency' => $currency,
        'receipt_email' => $customer['email'],
        'automatic_payment_methods[enabled]' => 'true',
        'metadata[devone_commerce]' => '1',
        'metadata[payment_environment]' => dvc_payment_environment(),
        'metadata[customer_name]' => $customer['name'],
        'metadata[customer_email]' => $customer['email'],
        'metadata[cart_items]' => (string)count($totals['items']),
    ));
    return array('success'=>true, 'client_secret'=>$pi['client_secret'] ?? '', 'id'=>$pi['id'] ?? '', 'total'=>dvc_money($totals['total']), 'totals'=>$totals);
}

function dvc_stripe_retrieve_payment_intent($id) {
    $secret = dvc_stripe_secret_key();
    if ($secret === '') { throw new Exception('Stripe Secret Key is missing in Commerce Settings.'); }
    if (!function_exists('curl_init')) { throw new Exception('PHP cURL extension is required for Stripe.'); }
    $ch = curl_init('https://api.stripe.com/v1/payment_intents/' . rawurlencode($id));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERPWD, $secret . ':');
    $raw = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    if ($raw === false) { throw new Exception($err ?: 'Stripe retrieve failed.'); }
    $json = json_decode($raw, true);
    if ($code >= 400) { throw new Exception('Stripe HTTP error ' . $code . ': ' . ($json['error']['message'] ?? $raw)); }
    return $json;
}

function dvc_stripe_finalize_order($payload) {
    $id = trim((string)($payload['payment_intent'] ?? ''));
    if ($id === '') { throw new Exception('Missing Stripe PaymentIntent ID.'); }
    $pi = dvc_stripe_retrieve_payment_intent($id);
    if (($pi['status'] ?? '') !== 'succeeded') { throw new Exception('Stripe payment was not successful. Status: ' . ($pi['status'] ?? 'unknown')); }
    return dvc_create_order_record($payload, 'stripe', 'paid', $id);
}

function dvc_paypal_base_url() {
    return dvc_paypal_environment() === 'live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';
}

function dvc_paypal_access_token() {
    $client = dvc_paypal_client_id();
    $secret = dvc_paypal_secret();
    if ($client === '' || $secret === '') { throw new Exception('PayPal Client ID and Secret are required in Commerce Settings.'); }
    $res = dvc_http_post(dvc_paypal_base_url() . '/v1/oauth2/token', array('Accept: application/json','Accept-Language: en_US','Content-Type: application/x-www-form-urlencoded'), 'grant_type=client_credentials', $client . ':' . $secret);
    if (empty($res['access_token'])) { throw new Exception('PayPal access token could not be created.'); }
    return $res['access_token'];
}

function dvc_paypal_create_order($payload) {
    $cart = isset($payload['cart']) && is_array($payload['cart']) ? $payload['cart'] : array();
    if (!$cart) { throw new Exception('Cart is empty.'); }
    $customer = dvc_customer_from_payload($payload);
    $totals = dvc_cart_totals($cart);
    $token = dvc_paypal_access_token();
    $currency = strtoupper((string)dvc_setting('currency','USD'));
    $items = array();
    foreach ($totals['items'] as $item) {
        $label = (string)$item['name'];
        if (!empty($item['variation'])) { $label .= ' - ' . (string)$item['variation']; }
        $items[] = array(
            'name' => substr($label, 0, 127),
            'quantity' => (string)max(1, (int)$item['qty']),
            'unit_amount' => array('currency_code'=>$currency, 'value'=>number_format((float)$item['price'], 2, '.', '')),
        );
    }
    $country = strtoupper(substr(trim((string)($payload['country'] ?? 'US')), 0, 2));
    if (!preg_match('/^[A-Z]{2}$/', $country)) { $country = 'US'; }
    $address = array(
        'address_line_1' => trim((string)($payload['address1'] ?? '')),
        'address_line_2' => trim((string)($payload['address2'] ?? '')),
        'admin_area_2' => trim((string)($payload['city'] ?? '')),
        'admin_area_1' => trim((string)($payload['state'] ?? '')),
        'postal_code' => trim((string)($payload['postal'] ?? '')),
        'country_code' => $country,
    );
    $purchaseUnit = array(
        'amount' => array(
            'currency_code'=>$currency,
            'value'=>number_format($totals['total'], 2, '.', ''),
            'breakdown'=>array(
                'item_total'=>array('currency_code'=>$currency, 'value'=>number_format($totals['subtotal'], 2, '.', '')),
                'tax_total'=>array('currency_code'=>$currency, 'value'=>number_format($totals['tax'], 2, '.', '')),
                'shipping'=>array('currency_code'=>$currency, 'value'=>number_format($totals['shipping'], 2, '.', '')),
            )
        ),
        'description' => dvc_setting('store_name','DevOne Commerce') . ' Order',
        'items' => $items,
    );
    if ($address['address_line_1'] !== '') {
        $purchaseUnit['shipping'] = array('name'=>array('full_name'=>$customer['name']), 'address'=>$address);
    }
    $body = json_encode(array(
        'intent' => 'CAPTURE',
        'payer' => array('email_address'=>$customer['email'], 'name'=>array('given_name'=>$customer['name'])),
        'purchase_units' => array($purchaseUnit),
    ));
    $res = dvc_http_post(dvc_paypal_base_url() . '/v2/checkout/orders', array('Content-Type: application/json','Authorization: Bearer ' . $token), $body);
    return array('success'=>true, 'id'=>$res['id'] ?? '', 'total'=>dvc_money($totals['total']), 'totals'=>$totals);
}

function dvc_paypal_capture_order($payload) {
    $orderId = trim((string)($payload['order_id'] ?? ''));
    if ($orderId === '') { throw new Exception('Missing PayPal order ID.'); }
    $token = dvc_paypal_access_token();
    $res = dvc_http_post(dvc_paypal_base_url() . '/v2/checkout/orders/' . rawurlencode($orderId) . '/capture', array('Content-Type: application/json','Authorization: Bearer ' . $token), '{}');
    if (($res['status'] ?? '') !== 'COMPLETED') { throw new Exception('PayPal payment was not completed. Status: ' . ($res['status'] ?? 'unknown')); }
    return dvc_create_order_record($payload, 'paypal', 'paid', $orderId);
}
