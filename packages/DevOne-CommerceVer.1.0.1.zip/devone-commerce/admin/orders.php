<?php
if (!defined('DEVONE_PLUGIN_ADMIN_ROUTER')) { http_response_code(403); exit('Use DevOneCMS admin router.'); }
require_once dirname(__DIR__) . '/includes/commerce.php';
dvc_install();

function dvc_admin_order_items_for_display($orders) {
    $itemsByOrder = array();
    if (!$orders) { return $itemsByOrder; }
    $ids = array();
    foreach ($orders as $order) {
        $id = (int)($order['id'] ?? 0);
        if ($id > 0) { $ids[] = $id; }
    }
    $ids = array_values(array_unique($ids));
    if ($ids) {
        try {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $stmt = db()->prepare('SELECT * FROM `' . dvc_table('order_items') . '` WHERE order_id IN (' . $placeholders . ') ORDER BY id ASC');
            $stmt->execute($ids);
            foreach ($stmt->fetchAll() as $item) {
                $oid = (int)($item['order_id'] ?? 0);
                if (!isset($itemsByOrder[$oid])) { $itemsByOrder[$oid] = array(); }
                $itemsByOrder[$oid][] = array(
                    'product_id' => (int)($item['product_id'] ?? 0),
                    'name' => (string)($item['product_name'] ?? 'Product'),
                    'variation' => (string)($item['variation'] ?? ''),
                    'type' => (string)($item['product_type'] ?? ''),
                    'qty' => (int)($item['quantity'] ?? 1),
                    'price' => (float)($item['price'] ?? 0),
                    'line_total' => (float)($item['line_total'] ?? 0),
                    'shipping' => null,
                    'image' => '',
                );
            }
        } catch (Throwable $e) {}
    }

    foreach ($orders as $order) {
        $oid = (int)($order['id'] ?? 0);
        $cart = json_decode((string)($order['cart_json'] ?? ''), true);
        if (!is_array($cart)) { $cart = array(); }
        $cartLookup = array();
        foreach ($cart as $ci) {
            $key = (int)($ci['id'] ?? 0) . '::' . trim((string)($ci['variation'] ?? ''));
            $cartLookup[$key] = $ci;
        }
        if (empty($itemsByOrder[$oid]) && $cart) {
            $itemsByOrder[$oid] = array();
            foreach ($cart as $ci) {
                $itemsByOrder[$oid][] = array(
                    'product_id' => (int)($ci['id'] ?? 0),
                    'name' => (string)($ci['name'] ?? 'Product'),
                    'variation' => (string)($ci['variation'] ?? ''),
                    'type' => (string)($ci['type'] ?? ''),
                    'qty' => (int)($ci['qty'] ?? 1),
                    'price' => (float)($ci['price'] ?? 0),
                    'line_total' => (float)($ci['line_total'] ?? ((float)($ci['price'] ?? 0) * (int)($ci['qty'] ?? 1))),
                    'shipping' => isset($ci['shipping']) ? (float)$ci['shipping'] : null,
                    'image' => (string)($ci['image'] ?? ''),
                );
            }
            continue;
        }
        if (!empty($itemsByOrder[$oid]) && $cartLookup) {
            foreach ($itemsByOrder[$oid] as $k => $item) {
                $key = (int)($item['product_id'] ?? 0) . '::' . trim((string)($item['variation'] ?? ''));
                if (isset($cartLookup[$key])) {
                    $itemsByOrder[$oid][$k]['image'] = (string)($cartLookup[$key]['image'] ?? '');
                    $itemsByOrder[$oid][$k]['shipping'] = isset($cartLookup[$key]['shipping']) ? (float)$cartLookup[$key]['shipping'] : null;
                }
            }
        }
    }
    return $itemsByOrder;
}

function dvc_admin_address_html($address) {
    $address = trim((string)$address);
    if ($address === '') { return '<span class="dvc-empty-text">No address captured for this order.</span>'; }
    $parts = preg_split('/\r\n|\r|\n/', $address);
    $out = array();
    foreach ($parts as $p) {
        $p = trim($p);
        if ($p !== '') { $out[] = e($p); }
    }
    return $out ? implode('<br>', $out) : '<span class="dvc-empty-text">No address captured for this order.</span>';
}

function dvc_admin_status_class($status) {
    $status = strtolower((string)$status);
    if (strpos($status, 'paid') !== false || strpos($status, 'success') !== false) { return 'paid'; }
    if (strpos($status, 'fail') !== false || strpos($status, 'declined') !== false || strpos($status, 'cancel') !== false) { return 'failed'; }
    return 'pending';
}

$orders = array();
try { $orders = db()->query('SELECT * FROM `' . dvc_table('orders') . '` ORDER BY id DESC LIMIT 100')->fetchAll(); }
catch (Throwable $e) {}
$itemsByOrder = dvc_admin_order_items_for_display($orders);
?>
<style>
.dvc-orders-page {
  display: grid;
  gap: 18px;
}
.dvc-orders-head {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 16px;
  flex-wrap: wrap;
}
.dvc-orders-head h1 { margin-bottom: 6px; }
.dvc-orders-note {
  margin: 0;
  color: #aebcff;
  line-height: 1.55;
}
.dvc-orders-accordion {
  display: grid;
  gap: 14px;
}
.dvc-order-card {
  overflow: hidden;
  border-radius: 24px;
  border: 1px solid rgba(130,160,255,.22);
  background:
    radial-gradient(circle at top right, rgba(39,183,255,.10), transparent 38%),
    linear-gradient(145deg, rgba(255,255,255,.075), rgba(255,255,255,.026));
  box-shadow: 0 16px 54px rgba(0,0,0,.18);
}
.dvc-order-card summary {
  list-style: none;
  cursor: pointer;
}
.dvc-order-card summary::-webkit-details-marker { display: none; }
.dvc-order-summary {
  display: grid;
  grid-template-columns: 1.1fr 1.35fr .8fr .9fr .9fr 1fr 54px;
  gap: 14px;
  align-items: center;
  padding: 18px;
}
.dvc-order-label {
  display: block;
  color: #94a4e8;
  font-size: .72rem;
  font-weight: 950;
  text-transform: uppercase;
  letter-spacing: .08em;
  margin-bottom: 5px;
}
.dvc-order-value {
  color: #fff;
  font-weight: 900;
}
.dvc-order-value small,
.dvc-order-customer small {
  display: block;
  color: #aebcff;
  font-weight: 700;
  margin-top: 3px;
}
.dvc-order-status {
  display: inline-flex;
  align-items: center;
  width: fit-content;
  min-height: 30px;
  padding: 0 11px;
  border-radius: 999px;
  font-size: .78rem;
  font-weight: 950;
  text-transform: uppercase;
  letter-spacing: .055em;
  border: 1px solid rgba(255,255,255,.12);
}
.dvc-order-status.paid {
  color: #dfffee;
  background: rgba(49,243,173,.12);
  border-color: rgba(49,243,173,.26);
}
.dvc-order-status.pending {
  color: #fff1c7;
  background: rgba(255,202,71,.12);
  border-color: rgba(255,202,71,.28);
}
.dvc-order-status.failed {
  color: #ffd7df;
  background: rgba(255,77,109,.12);
  border-color: rgba(255,77,109,.28);
}
.dvc-order-arrow {
  width: 44px;
  height: 44px;
  display: grid;
  place-items: center;
  justify-self: end;
  border-radius: 16px;
  color: #fff;
  background: linear-gradient(135deg, rgba(39,183,255,.26), rgba(149,67,255,.24));
  border: 1px solid rgba(130,160,255,.28);
  transition: transform .18s ease;
  font-size: 1.25rem;
  font-weight: 950;
}
.dvc-order-card[open] .dvc-order-arrow { transform: rotate(180deg); }
.dvc-order-details {
  padding: 0 18px 18px;
}
.dvc-order-details-inner {
  display: grid;
  gap: 18px;
  padding: 18px;
  border-radius: 22px;
  border: 1px solid rgba(255,255,255,.09);
  background: rgba(0,0,0,.20);
}
.dvc-order-detail-grid {
  display: grid;
  grid-template-columns: 1.45fr .85fr;
  gap: 18px;
  align-items: start;
}
.dvc-order-box {
  border-radius: 20px;
  border: 1px solid rgba(130,160,255,.16);
  background: rgba(255,255,255,.045);
  padding: 16px;
}
.dvc-order-box h3 {
  margin: 0 0 12px;
  color: #fff;
}
.dvc-order-items {
  display: grid;
  gap: 10px;
}
.dvc-order-item {
  display: grid;
  grid-template-columns: 56px 1fr auto;
  gap: 13px;
  align-items: center;
  padding: 12px;
  border-radius: 16px;
  background: rgba(255,255,255,.055);
  border: 1px solid rgba(255,255,255,.075);
}
.dvc-order-item-img {
  width: 56px;
  height: 56px;
  border-radius: 14px;
  object-fit: cover;
  background: linear-gradient(135deg, rgba(39,183,255,.20), rgba(149,67,255,.22));
}
.dvc-order-item-img.dvc-placeholder {
  display: grid;
  place-items: center;
  color: #cbd7ff;
  font-weight: 950;
}
.dvc-order-item h4 {
  margin: 0 0 3px;
  color: #fff;
}
.dvc-order-item p {
  margin: 0;
  color: #aebcff;
  line-height: 1.45;
  font-size: .9rem;
}
.dvc-order-line-total {
  text-align: right;
  color: #fff;
  font-weight: 950;
  white-space: nowrap;
}
.dvc-order-line-total small {
  display: block;
  margin-top: 4px;
  color: #aebcff;
  font-weight: 700;
}
.dvc-order-info-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
}
.dvc-order-info-grid .dvc-order-box { min-height: 100%; }
.dvc-order-field {
  display: grid;
  gap: 3px;
  margin: 0 0 10px;
  color: #dbe4ff;
  line-height: 1.5;
}
.dvc-order-field b {
  color: #94a4e8;
  font-size: .75rem;
  text-transform: uppercase;
  letter-spacing: .08em;
}
.dvc-order-totals {
  display: grid;
  gap: 8px;
}
.dvc-order-total-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  color: #dbe4ff;
}
.dvc-order-total-row strong { color: #fff; }
.dvc-order-total-row.grand {
  margin-top: 8px;
  padding-top: 10px;
  border-top: 1px solid rgba(255,255,255,.12);
  font-size: 1.12rem;
}
.dvc-empty-text { color: #aebcff; font-style: italic; }
@media (max-width: 1180px) {
  .dvc-order-summary { grid-template-columns: repeat(2, minmax(0, 1fr)) 54px; }
  .dvc-order-summary > div:nth-child(6) { grid-column: span 2; }
  .dvc-order-arrow { grid-column: 3; grid-row: 1; }
  .dvc-order-detail-grid { grid-template-columns: 1fr; }
}
@media (max-width: 720px) {
  .dvc-order-summary { grid-template-columns: 1fr 48px; }
  .dvc-order-summary > div { grid-column: 1; }
  .dvc-order-summary > div:nth-child(6) { grid-column: 1; }
  .dvc-order-arrow { grid-column: 2; grid-row: 1; }
  .dvc-order-info-grid { grid-template-columns: 1fr; }
  .dvc-order-item { grid-template-columns: 48px 1fr; }
  .dvc-order-line-total { grid-column: 1 / -1; text-align: left; }
}
</style>

<div class="dvc-orders-page">
  <div class="dvc-orders-head">
    <div>
      <h1>Commerce Orders</h1>
      <p class="dvc-orders-note">Orders are saved inside DevOne Commerce even when Stripe or PayPal are not connected. Open an order to view purchased products, options, customer info, address, totals, and payment details.</p>
    </div>
    <a class="button secondary" href="plugin-page.php?plugin=devone-commerce&page=products">← Commerce</a>
  </div>

  <?php if (!$orders): ?>
    <section class="card"><p>No orders yet. Visit the Shop page, add products to the cart, and run checkout.</p></section>
  <?php else: ?>
    <div class="dvc-orders-accordion">
      <?php foreach ($orders as $o):
          $oid = (int)($o['id'] ?? 0);
          $orderItems = $itemsByOrder[$oid] ?? array();
          $status = (string)($o['status'] ?? 'pending');
          $gateway = (string)($o['gateway'] ?? 'test');
          $date = (string)($o['created_at'] ?? '');
          $phone = trim((string)($o['customer_phone'] ?? ''));
          $reference = trim((string)($o['payment_reference'] ?? ''));
      ?>
      <details class="dvc-order-card">
        <summary>
          <div class="dvc-order-summary">
            <div>
              <span class="dvc-order-label">Order</span>
              <span class="dvc-order-value"><?= e($o['order_number'] ?? '') ?><?php if ($reference !== ''): ?><small><?= e($reference) ?></small><?php endif; ?></span>
            </div>
            <div class="dvc-order-customer">
              <span class="dvc-order-label">Customer</span>
              <span class="dvc-order-value"><?= e($o['customer_name'] ?? '') ?></span>
              <small><?= e($o['customer_email'] ?? '') ?></small>
              <?php if ($phone !== ''): ?><small><?= e($phone) ?></small><?php endif; ?>
            </div>
            <div>
              <span class="dvc-order-label">Status</span>
              <span class="dvc-order-status <?= e(dvc_admin_status_class($status)) ?>"><?= e($status) ?></span>
            </div>
            <div>
              <span class="dvc-order-label">Gateway</span>
              <span class="dvc-order-value"><?= e($gateway) ?></span>
            </div>
            <div>
              <span class="dvc-order-label">Total</span>
              <span class="dvc-order-value"><?= e(dvc_money($o['total'] ?? 0)) ?></span>
            </div>
            <div>
              <span class="dvc-order-label">Purchase Date</span>
              <span class="dvc-order-value"><?= e($date) ?></span>
            </div>
            <span class="dvc-order-arrow" aria-hidden="true">⌄</span>
          </div>
        </summary>

        <div class="dvc-order-details">
          <div class="dvc-order-details-inner">
            <div class="dvc-order-detail-grid">
              <section class="dvc-order-box">
                <h3>Purchased Items</h3>
                <?php if (!$orderItems): ?>
                  <p class="dvc-empty-text">No line items found for this order.</p>
                <?php else: ?>
                  <div class="dvc-order-items">
                    <?php foreach ($orderItems as $item):
                        $qty = max(1, (int)($item['qty'] ?? 1));
                        $type = trim((string)($item['type'] ?? ''));
                        $variation = trim((string)($item['variation'] ?? ''));
                        $ship = $item['shipping'];
                        $image = trim((string)($item['image'] ?? ''));
                    ?>
                    <div class="dvc-order-item">
                      <?php if ($image !== ''): ?>
                        <img class="dvc-order-item-img" src="<?= e($image) ?>" alt="<?= e($item['name'] ?? 'Product') ?>">
                      <?php else: ?>
                        <span class="dvc-order-item-img dvc-placeholder">DVC</span>
                      <?php endif; ?>
                      <div>
                        <h4><?= e($item['name'] ?? 'Product') ?></h4>
                        <p>
                          Qty: <?= (int)$qty ?> · Unit: <?= e(dvc_money($item['price'] ?? 0)) ?><?php if ($type !== ''): ?> · Type: <?= e(ucfirst($type)) ?><?php endif; ?>
                          <?php if ($variation !== ''): ?><br><strong>Variation:</strong> <?= e($variation) ?><?php endif; ?>
                          <?php if ($ship !== null && (float)$ship > 0): ?><br><strong>Shipping line:</strong> <?= e(dvc_money($ship)) ?><?php endif; ?>
                        </p>
                      </div>
                      <div class="dvc-order-line-total">
                        <?= e(dvc_money($item['line_total'] ?? 0)) ?>
                        <small>Line total</small>
                      </div>
                    </div>
                    <?php endforeach; ?>
                  </div>
                <?php endif; ?>
              </section>

              <aside class="dvc-order-box">
                <h3>Order Totals</h3>
                <div class="dvc-order-totals">
                  <div class="dvc-order-total-row"><span>Subtotal</span><strong><?= e(dvc_money($o['subtotal'] ?? 0)) ?></strong></div>
                  <div class="dvc-order-total-row"><span>Tax</span><strong><?= e(dvc_money($o['tax_amount'] ?? 0)) ?></strong></div>
                  <div class="dvc-order-total-row"><span>Shipping</span><strong><?= e(dvc_money($o['shipping_amount'] ?? 0)) ?></strong></div>
                  <div class="dvc-order-total-row grand"><span>Total Paid</span><strong><?= e(dvc_money($o['total'] ?? 0)) ?></strong></div>
                </div>
              </aside>
            </div>

            <div class="dvc-order-info-grid">
              <section class="dvc-order-box">
                <h3>Customer Info</h3>
                <p class="dvc-order-field"><b>Name</b><span><?= e($o['customer_name'] ?? '') ?></span></p>
                <p class="dvc-order-field"><b>Email</b><span><?= e($o['customer_email'] ?? '') ?></span></p>
                <p class="dvc-order-field"><b>Phone</b><span><?= $phone !== '' ? e($phone) : '<span class="dvc-empty-text">No phone captured.</span>' ?></span></p>
              </section>

              <section class="dvc-order-box">
                <h3>Billing / Shipping Info</h3>
                <p class="dvc-order-field"><b>Checkout Address</b><span><?= dvc_admin_address_html($o['billing_address'] ?? '') ?></span></p>
                <p class="dvc-order-field"><b>Note</b><span>This checkout address is saved with the order before payment gateway card handling.</span></p>
              </section>

              <section class="dvc-order-box">
                <h3>Payment Info</h3>
                <p class="dvc-order-field"><b>Gateway</b><span><?= e($gateway) ?></span></p>
                <p class="dvc-order-field"><b>Status</b><span><?= e($status) ?></span></p>
                <p class="dvc-order-field"><b>Payment Reference</b><span><?= $reference !== '' ? e($reference) : '<span class="dvc-empty-text">No reference saved yet.</span>' ?></span></p>
              </section>

              <section class="dvc-order-box">
                <h3>Order Details</h3>
                <p class="dvc-order-field"><b>Order ID</b><span>#<?= (int)$oid ?></span></p>
                <p class="dvc-order-field"><b>Order Number</b><span><?= e($o['order_number'] ?? '') ?></span></p>
                <p class="dvc-order-field"><b>Purchase Date</b><span><?= e($date) ?></span></p>
              </section>
            </div>
          </div>
        </div>
      </details>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
