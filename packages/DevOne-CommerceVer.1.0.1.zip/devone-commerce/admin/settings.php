<?php
if (!defined('DEVONE_PLUGIN_ADMIN_ROUTER')) { http_response_code(403); exit('Use DevOneCMS admin router.'); }
require_once dirname(__DIR__) . '/includes/commerce.php';
dvc_install();
$msg = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['dvc_action'] ?? '') === 'save_settings') {
    try {
        if (function_exists('verify_csrf')) { verify_csrf(); }
        $gatewayMode = in_array($_POST['gateway_mode'] ?? 'test', array('test','stripe','paypal','both'), true) ? $_POST['gateway_mode'] : 'test';
        $paymentEnv = ($_POST['payment_environment'] ?? 'test') === 'live' ? 'live' : 'test';
        $keys = array(
            'store_name','currency','tax_percent','gateway_mode','payment_environment','enabled_gateways',
            'stripe_test_publishable_key','stripe_test_secret_key','stripe_test_webhook_secret',
            'stripe_live_publishable_key','stripe_live_secret_key','stripe_live_webhook_secret',
            'paypal_sandbox_client_id','paypal_sandbox_secret','paypal_sandbox_webhook_id',
            'paypal_live_client_id','paypal_live_secret','paypal_live_webhook_id'
        );
        $_POST['gateway_mode'] = $gatewayMode;
        $_POST['payment_environment'] = $paymentEnv;
        $_POST['enabled_gateways'] = $gatewayMode;
        foreach ($keys as $key) { dvc_set_setting($key, trim((string)($_POST[$key] ?? ''))); }

        // Keep legacy alpha settings in sync for backwards compatibility.
        dvc_set_setting('paypal_environment', $paymentEnv === 'live' ? 'live' : 'sandbox');
        dvc_set_setting('stripe_publishable_key', $paymentEnv === 'live' ? trim((string)($_POST['stripe_live_publishable_key'] ?? '')) : trim((string)($_POST['stripe_test_publishable_key'] ?? '')));
        dvc_set_setting('stripe_secret_key', $paymentEnv === 'live' ? trim((string)($_POST['stripe_live_secret_key'] ?? '')) : trim((string)($_POST['stripe_test_secret_key'] ?? '')));
        dvc_set_setting('stripe_webhook_secret', $paymentEnv === 'live' ? trim((string)($_POST['stripe_live_webhook_secret'] ?? '')) : trim((string)($_POST['stripe_test_webhook_secret'] ?? '')));
        dvc_set_setting('paypal_client_id', $paymentEnv === 'live' ? trim((string)($_POST['paypal_live_client_id'] ?? '')) : trim((string)($_POST['paypal_sandbox_client_id'] ?? '')));
        dvc_set_setting('paypal_secret', $paymentEnv === 'live' ? trim((string)($_POST['paypal_live_secret'] ?? '')) : trim((string)($_POST['paypal_sandbox_secret'] ?? '')));
        dvc_set_setting('paypal_webhook_id', $paymentEnv === 'live' ? trim((string)($_POST['paypal_live_webhook_id'] ?? '')) : trim((string)($_POST['paypal_sandbox_webhook_id'] ?? '')));
        $msg = 'Commerce gateway settings saved.';
    } catch (Throwable $e) { $error = $e->getMessage(); }
}

$mode = dvc_gateway_mode();
$env = dvc_payment_environment();
$webhookUrl = rtrim(DVC_PLUGIN_URL, '/') . '/webhook.php';
?>
<h1>Commerce Settings</h1>
<p class="muted">Configure store tax, gateway display, and Test/Live credentials for Stripe and PayPal. DevOne Commerce still captures the order details before the gateway handles card/payment data.</p>
<?php devone_flash($msg); devone_flash($error, 'card error-card'); ?>

<form method="post" class="card dvc-commerce-settings dvc-gateway-settings">
  <?= csrf_field() ?>
  <input type="hidden" name="dvc_action" value="save_settings">

  <section class="dvc-settings-section">
    <h3>Store</h3>
    <div class="dashboard-grid">
      <label>Store Name<input name="store_name" value="<?= e(dvc_setting('store_name','DevOne Commerce Demo Shop')) ?>"></label>
      <label>Currency<input name="currency" value="<?= e(strtoupper((string)dvc_setting('currency','USD'))) ?>" placeholder="USD"></label>
    </div>
    <label>Cart Tax Percent <small>Applied to the product subtotal at checkout.</small><input name="tax_percent" type="number" step="0.01" min="0" value="<?= e(dvc_setting('tax_percent','0')) ?>" placeholder="8.9"></label>
  </section>

  <section class="dvc-settings-section">
    <h3>Checkout Gateway Controls</h3>
    <div class="dashboard-grid">
      <label>Gateway Display
        <select name="gateway_mode">
          <?php foreach(array('test'=>'Test / Manual Checkout','stripe'=>'Stripe Only','paypal'=>'PayPal Only','both'=>'Stripe + PayPal') as $k=>$v): ?>
          <option value="<?= e($k) ?>" <?= $mode===$k?'selected':'' ?>><?= e($v) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label>Payment Environment
        <select name="payment_environment">
          <option value="test" <?= $env === 'test' ? 'selected' : '' ?>>Test / Sandbox</option>
          <option value="live" <?= $env === 'live' ? 'selected' : '' ?>>Live / Production</option>
        </select>
      </label>
    </div>
    <div class="dvc-settings-note">
      <strong>How this works:</strong> choose <code>Stripe + PayPal</code> to show both payment options in the cart modal. The Test/Live toggle decides which saved keys are used. Card information is collected by Stripe or PayPal, not stored inside DevOneCMS.
    </div>
    <label>Webhook Endpoint <small>Use this URL later for Stripe/PayPal webhook setup. This build keeps checkout server-confirmed after payment capture.</small><input readonly value="<?= e($webhookUrl) ?>" onclick="this.select()"></label>
  </section>

  <section class="dvc-settings-section dvc-gateway-grid">
    <div class="dvc-gateway-card">
      <div class="dvc-gateway-card-head">
        <h3>Stripe Test</h3>
        <span>Sandbox</span>
      </div>
      <p class="muted">Use <code>pk_test_...</code> and <code>sk_test_...</code> first.</p>
      <label>Publishable Key<input name="stripe_test_publishable_key" value="<?= e(dvc_setting('stripe_test_publishable_key', dvc_setting('stripe_publishable_key',''))) ?>" placeholder="pk_test_..."></label>
      <label>Secret Key<input name="stripe_test_secret_key" type="password" value="<?= e(dvc_setting('stripe_test_secret_key', dvc_setting('stripe_secret_key',''))) ?>" placeholder="sk_test_..."></label>
      <label>Webhook Secret<input name="stripe_test_webhook_secret" type="password" value="<?= e(dvc_setting('stripe_test_webhook_secret', dvc_setting('stripe_webhook_secret',''))) ?>" placeholder="whsec_..."></label>
    </div>

    <div class="dvc-gateway-card live">
      <div class="dvc-gateway-card-head">
        <h3>Stripe Live</h3>
        <span>Production</span>
      </div>
      <p class="muted">Only use these after sandbox payments are working.</p>
      <label>Publishable Key<input name="stripe_live_publishable_key" value="<?= e(dvc_setting('stripe_live_publishable_key','')) ?>" placeholder="pk_live_..."></label>
      <label>Secret Key<input name="stripe_live_secret_key" type="password" value="<?= e(dvc_setting('stripe_live_secret_key','')) ?>" placeholder="sk_live_..."></label>
      <label>Webhook Secret<input name="stripe_live_webhook_secret" type="password" value="<?= e(dvc_setting('stripe_live_webhook_secret','')) ?>" placeholder="whsec_..."></label>
    </div>
  </section>

  <section class="dvc-settings-section dvc-gateway-grid">
    <div class="dvc-gateway-card">
      <div class="dvc-gateway-card-head">
        <h3>PayPal Sandbox</h3>
        <span>Test</span>
      </div>
      <p class="muted">Use PayPal developer sandbox app credentials.</p>
      <label>Client ID<input name="paypal_sandbox_client_id" value="<?= e(dvc_setting('paypal_sandbox_client_id', dvc_setting('paypal_client_id',''))) ?>"></label>
      <label>Secret<input name="paypal_sandbox_secret" type="password" value="<?= e(dvc_setting('paypal_sandbox_secret', dvc_setting('paypal_secret',''))) ?>"></label>
      <label>Webhook ID<input name="paypal_sandbox_webhook_id" value="<?= e(dvc_setting('paypal_sandbox_webhook_id', dvc_setting('paypal_webhook_id',''))) ?>"></label>
    </div>

    <div class="dvc-gateway-card live">
      <div class="dvc-gateway-card-head">
        <h3>PayPal Live</h3>
        <span>Production</span>
      </div>
      <p class="muted">Use live app credentials only after sandbox checkout is working.</p>
      <label>Client ID<input name="paypal_live_client_id" value="<?= e(dvc_setting('paypal_live_client_id','')) ?>"></label>
      <label>Secret<input name="paypal_live_secret" type="password" value="<?= e(dvc_setting('paypal_live_secret','')) ?>"></label>
      <label>Webhook ID<input name="paypal_live_webhook_id" value="<?= e(dvc_setting('paypal_live_webhook_id','')) ?>"></label>
    </div>
  </section>

  <button>Save Commerce Settings</button>
</form>
