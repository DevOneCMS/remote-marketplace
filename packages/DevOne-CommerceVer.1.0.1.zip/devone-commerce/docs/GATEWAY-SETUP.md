# Stripe and PayPal Setup

## Stripe

1. Go to **Commerce → Commerce Settings**.
2. Set **Gateway Display** to **Stripe Only** or **Stripe + PayPal**.
3. Set **Payment Environment** to **Test / Sandbox** while testing.
4. Enter your Stripe test publishable key and test secret key.
5. Test checkout using Stripe test card numbers.
6. Switch to **Live / Production** only after successful testing.
7. Enter your Stripe live publishable key and live secret key.

## PayPal

1. Go to **Commerce → Commerce Settings**.
2. Set **Gateway Display** to **PayPal Only** or **Stripe + PayPal**.
3. Set **Payment Environment** to **Test / Sandbox** while testing.
4. Enter your PayPal sandbox Client ID and Secret.
5. Test with a PayPal sandbox buyer account.
6. Switch to **Live / Production** only after successful sandbox testing.
7. Enter your PayPal live Client ID and Secret.

## Important

DevOne Commerce stores order information and gateway payment references. Stripe and PayPal handle sensitive card/payment details.
