<?php
function devone_form_lite_shortcode(){ return '<form class="devone-demo-form"><input placeholder="Name"><input placeholder="Email"><button type="button">Send</button></form>'; }
?>
