<?php
add_action('wp_head', function(){ echo "<!-- DevOne SEO Spark Lite ready -->\n"; });
?>
