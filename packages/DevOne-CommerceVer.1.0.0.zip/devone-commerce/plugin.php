<?php
/**
 * Plugin Name: DevOne Commerce
 * Description: WooCommerce-style ecommerce plugin for DevOneCMS with products, cart modal checkout, orders, Stripe, PayPal, tax, shipping, and receipt emails.
 * Version: 1.0.0
 * Author: Developer One Inc.
 */

if (!defined('DVC_PLUGIN_SLUG')) { define('DVC_PLUGIN_SLUG', 'devone-commerce'); }
if (!defined('DVC_PLUGIN_FOLDER')) { define('DVC_PLUGIN_FOLDER', basename(__DIR__)); }
require_once __DIR__ . '/includes/commerce.php';

// Install/repair plugin tables and seed the Shop page whenever the active plugin loads.
dvc_install();

if (function_exists('devone_register_plugin_admin_page')) {
    devone_register_plugin_admin_page(DVC_PLUGIN_SLUG, 'products', 'DevOne Commerce', __DIR__ . '/admin/products.php', 'manage_plugins', 'Commerce');
    devone_register_plugin_admin_page(DVC_PLUGIN_SLUG, 'add-product', 'Add Product', __DIR__ . '/admin/products.php', 'manage_plugins', 'Add Product');
    devone_register_plugin_admin_page(DVC_PLUGIN_SLUG, 'orders', 'Commerce Orders', __DIR__ . '/admin/orders.php', 'manage_plugins', 'Orders');
    devone_register_plugin_admin_page(DVC_PLUGIN_SLUG, 'settings', 'Commerce Settings', __DIR__ . '/admin/settings.php', 'manage_plugins', 'Commerce Settings');
}

if (function_exists('add_filter')) {
    add_filter('page_content', 'dvc_replace_shortcodes');
}
if (function_exists('add_action')) {
    add_action('wp_head', 'dvc_head_assets');
    add_action('wp_footer', 'dvc_footer_assets');
}
