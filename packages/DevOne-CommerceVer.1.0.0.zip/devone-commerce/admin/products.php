<?php
if (!defined('DEVONE_PLUGIN_ADMIN_ROUTER')) { http_response_code(403); exit('Use DevOneCMS admin router.'); }
require_once dirname(__DIR__) . '/includes/commerce.php';
dvc_install();
$msg = '';
$error = '';

$baseProductsUrl = 'plugin-page.php?plugin=devone-commerce&page=products';
$addProductUrl = 'plugin-page.php?plugin=devone-commerce&page=add-product';

if (isset($_GET['dvc_notice'])) {
    $notice = preg_replace('/[^a-z0-9_\-]+/i', '', (string)$_GET['dvc_notice']);
    $messages = array(
        'created' => 'Product created. Showing all products.',
        'updated' => 'Product updated. Showing all products.',
        'deleted' => 'Product deleted.',
        'seeded' => 'Demo products reseeded.',
    );
    $msg = $messages[$notice] ?? '';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['dvc_action'] ?? '';
    try {
        if ($action === 'save_product') {
            if (function_exists('verify_csrf')) { verify_csrf(); }
            $id = (int)($_POST['id'] ?? 0);
            $name = trim((string)($_POST['name'] ?? ''));
            if ($name === '') { throw new Exception('Product name is required.'); }
            $slug = dvc_slug($_POST['slug'] ?? $name, 'product');
            $sku = trim((string)($_POST['sku'] ?? ''));
            $productType = in_array($_POST['product_type'] ?? 'physical', array('physical','digital','service'), true) ? $_POST['product_type'] : 'physical';
            $variations = trim((string)($_POST['variations'] ?? ''));
            $downloadUrl = trim((string)($_POST['download_url'] ?? ''));
            $serviceNote = trim((string)($_POST['service_note'] ?? ''));
            $shippingPrice = $productType === 'physical' ? (float)($_POST['shipping_price'] ?? 0) : 0.00;
            $price = (float)($_POST['price'] ?? 0);
            $sale = trim((string)($_POST['sale_price'] ?? ''));
            $saleValue = $sale === '' ? null : (float)$sale;
            $image = trim((string)($_POST['image'] ?? ''));
            $short = trim((string)($_POST['short_description'] ?? ''));
            $desc = trim((string)($_POST['description'] ?? ''));
            $status = in_array($_POST['status'] ?? 'published', array('published','draft'), true) ? $_POST['status'] : 'published';
            $stock = (int)($_POST['stock'] ?? 999);
            if ($id > 0) {
                $stmt = db()->prepare('UPDATE `' . dvc_table('products') . '` SET name=?,slug=?,sku=?,product_type=?,variations=?,download_url=?,service_note=?,shipping_price=?,price=?,sale_price=?,image=?,short_description=?,description=?,status=?,stock=? WHERE id=?');
                $stmt->execute(array($name,$slug,$sku,$productType,$variations,$downloadUrl,$serviceNote,$shippingPrice,$price,$saleValue,$image,$short,$desc,$status,$stock,$id));
                header('Location: ' . $baseProductsUrl . '&dvc_notice=updated');
                exit;
            }
            $stmt = db()->prepare('INSERT INTO `' . dvc_table('products') . '` (name,slug,sku,product_type,variations,download_url,service_note,shipping_price,price,sale_price,image,short_description,description,status,stock) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
            $stmt->execute(array($name,$slug,$sku,$productType,$variations,$downloadUrl,$serviceNote,$shippingPrice,$price,$saleValue,$image,$short,$desc,$status,$stock));
            header('Location: ' . $baseProductsUrl . '&dvc_notice=created');
            exit;
        }
        if ($action === 'delete_product') {
            if (function_exists('verify_csrf')) { verify_csrf(); }
            $id = (int)($_POST['id'] ?? 0);
            db()->prepare('DELETE FROM `' . dvc_table('products') . '` WHERE id=?')->execute(array($id));
            header('Location: ' . $baseProductsUrl . '&dvc_notice=deleted');
            exit;
        }
        if ($action === 'seed_demo') {
            if (function_exists('verify_csrf')) { verify_csrf(); }
            db()->exec('TRUNCATE TABLE `' . dvc_table('products') . '`');
            dvc_seed_products();
            header('Location: ' . $baseProductsUrl . '&dvc_notice=seeded');
            exit;
        }
    } catch (Throwable $e) { $error = $e->getMessage(); }
}

$currentPageSlug = strtolower(trim((string)($_GET['page'] ?? 'products')));
$editId = (int)($_GET['edit'] ?? 0);
$showEditor = ($currentPageSlug === 'add-product') || isset($_GET['new']) || $editId > 0;
$editing = $editId > 0 ? dvc_product($editId) : null;
$products = dvc_products(false);
$productType = $editing['product_type'] ?? 'physical';
?>

<?php if ($showEditor): ?>
  <div class="dvc-admin-title-row">
    <div>
      <h1><?= $editing ? 'Edit Product' : 'Add New Product' ?></h1>
      <p class="muted">Create physical products, digital downloads, or services. After saving, DevOne Commerce returns to All Products.</p>
    </div>
    <a class="button secondary" href="<?= e($baseProductsUrl) ?>">← All Products</a>
  </div>
  <?php devone_flash($error, 'card error-card'); ?>

  <form method="post" class="card dvc-product-editor-card" id="dvcProductEditor">
    <?= csrf_field() ?>
    <input type="hidden" name="dvc_action" value="save_product">
    <input type="hidden" name="id" value="<?= (int)($editing['id'] ?? 0) ?>">
    <div class="dashboard-grid dvc-editor-grid">
      <section>
        <h3>Product Details</h3>
        <label>Name<input name="name" required value="<?= e($editing['name'] ?? '') ?>"></label>
        <label>Slug<input name="slug" value="<?= e($editing['slug'] ?? '') ?>" placeholder="auto-generated from name"></label>
        <label>SKU<input name="sku" value="<?= e($editing['sku'] ?? '') ?>"></label>
        <label>Product Type
          <select name="product_type" id="dvcProductType">
            <option value="physical" <?= $productType === 'physical' ? 'selected' : '' ?>>Physical Product</option>
            <option value="digital" <?= $productType === 'digital' ? 'selected' : '' ?>>Digital Product / Download</option>
            <option value="service" <?= $productType === 'service' ? 'selected' : '' ?>>Service</option>
          </select>
        </label>
        <label>Variations / Options <small>Separate values with commas, like Small, Medium, Large, XL.</small><input name="variations" value="<?= e($editing['variations'] ?? '') ?>" placeholder="Small, Medium, Large, XL"></label>
        <label>Image URL<input name="image" value="<?= e($editing['image'] ?? '') ?>" placeholder="https://..."></label>
        <label>Short Description<textarea name="short_description" rows="4"><?= e($editing['short_description'] ?? '') ?></textarea></label>
        <label>Full Description<textarea name="description" rows="7"><?= e($editing['description'] ?? '') ?></textarea></label>
      </section>
      <aside>
        <h3>Pricing & Fulfillment</h3>
        <label>Price<input name="price" type="number" step="0.01" value="<?= e($editing['price'] ?? '0.00') ?>"></label>
        <label>Sale Price<input name="sale_price" type="number" step="0.01" value="<?= e($editing['sale_price'] ?? '') ?>"></label>
        <div class="dvc-conditional dvc-physical-only">
          <label>Shipping Price <small>Only charged for physical products.</small><input name="shipping_price" type="number" step="0.01" value="<?= e($editing['shipping_price'] ?? '0.00') ?>"></label>
        </div>
        <div class="dvc-conditional dvc-digital-only">
          <label>Download URL <small>Future secure-download delivery will use this.</small><input name="download_url" value="<?= e($editing['download_url'] ?? '') ?>" placeholder="https://..."></label>
        </div>
        <div class="dvc-conditional dvc-service-only">
          <label>Service Note <small>Example: 1 hour session, consultation, installation.</small><input name="service_note" value="<?= e($editing['service_note'] ?? '') ?>"></label>
        </div>
        <label>Status<select name="status"><option value="published" <?= (($editing['status'] ?? 'published') === 'published') ? 'selected' : '' ?>>Published</option><option value="draft" <?= (($editing['status'] ?? '') === 'draft') ? 'selected' : '' ?>>Draft</option></select></label>
        <label>Stock<input name="stock" type="number" value="<?= e($editing['stock'] ?? '999') ?>"></label>
        <button><?= $editing ? 'Update Product' : 'Create Product' ?></button>
        <a class="button secondary" href="<?= e($baseProductsUrl) ?>">Cancel</a>
      </aside>
    </div>
  </form>
  <script>
  (function(){
    function update(){
      var type = document.getElementById('dvcProductType');
      if(!type) return;
      document.querySelectorAll('.dvc-conditional').forEach(function(el){ el.style.display = 'none'; });
      document.querySelectorAll('.dvc-' + type.value + '-only').forEach(function(el){ el.style.display = ''; });
    }
    document.addEventListener('change', function(e){ if(e.target && e.target.id === 'dvcProductType') update(); });
    update();
  })();
  </script>

<?php else: ?>
  <div class="dvc-admin-title-row">
    <div>
      <h1>DevOne Commerce</h1>
      <p class="muted">All products are shown first. Use Add New Product when you are ready to create or edit items.</p>
    </div>
    <div class="inline-actions">
      <a class="button" href="<?= e($addProductUrl) ?>">+ Add New Product</a>
      <a class="button secondary" href="../index.php?page=shop" target="_blank" rel="noopener">View Shop Page</a>
    </div>
  </div>
  <?php devone_flash($msg); devone_flash($error, 'card error-card'); ?>

  <section class="card dvc-admin-products-card">
    <div class="dvc-admin-card-head">
      <div>
        <h3>All Products</h3>
        <p class="muted">Manage product cards that display on the front-end Shop page.</p>
      </div>
      <form method="post" onsubmit="return confirm('Replace existing products with demo products?');">
        <?= csrf_field() ?><input type="hidden" name="dvc_action" value="seed_demo">
        <button type="submit" class="secondary">Reseed Demo Products</button>
      </form>
    </div>

    <table class="table dvc-products-table">
      <tr><th>Image</th><th>Name</th><th>Type</th><th>Price</th><th>Shipping</th><th>Status</th><th>Stock</th><th>Actions</th></tr>
      <?php if (!$products): ?>
        <tr><td colspan="8">No products yet. Click <strong>Add New Product</strong> to create your first item.</td></tr>
      <?php endif; ?>
      <?php foreach ($products as $p): ?>
      <tr>
        <td><?php if (!empty($p['image'])): ?><img src="<?= e($p['image']) ?>" style="width:72px;height:52px;object-fit:cover;border-radius:12px;"> <?php endif; ?></td>
        <td><strong><?= e($p['name']) ?></strong><br><small><?= e($p['slug']) ?></small><?php if (!empty($p['variations'])): ?><br><small>Options: <?= e($p['variations']) ?></small><?php endif; ?></td>
        <td><?= e(ucfirst($p['product_type'] ?? 'physical')) ?></td>
        <td><?= e(dvc_money($p['sale_price'] !== null && $p['sale_price'] !== '' ? $p['sale_price'] : $p['price'])) ?></td>
        <td><?= e(dvc_money($p['shipping_price'] ?? 0)) ?></td>
        <td><?= e($p['status']) ?></td>
        <td><?= (int)$p['stock'] ?></td>
        <td class="inline-actions">
          <a class="button secondary" href="<?= e($addProductUrl . '&edit=' . (int)$p['id']) ?>">Edit</a>
          <form method="post" style="display:inline" onsubmit="return confirm('Delete this product?');"><?= csrf_field() ?><input type="hidden" name="dvc_action" value="delete_product"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button class="danger">Delete</button></form>
        </td>
      </tr>
      <?php endforeach; ?>
    </table>
  </section>
<?php endif; ?>
