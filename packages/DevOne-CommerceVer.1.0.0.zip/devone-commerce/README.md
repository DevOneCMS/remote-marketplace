# DevOne Commerce 1.0.0

**Author:** Developer One Inc.  
**Requires:** DevOneCMS 1.5.14 or newer  
**Type:** Plugin  
**Category:** Ecommerce

DevOne Commerce is a WooCommerce-style ecommerce plugin for DevOneCMS. It adds a full store foundation with product management, product cards, product variations/options, physical/digital/service product types, shipping, tax, a front-end cart modal, AJAX-style cart updates, order records, accordion order details, receipt emails, and Stripe/PayPal payment gateway support with Test/Sandbox and Live/Production modes.

## Main features

- Product manager with image, name, SKU, price, status, stock, and description fields.
- Product type selector for physical products, digital downloads, and services.
- Comma-separated product options/variations, such as sizes, licenses, or ticket levels.
- Conditional shipping price field for physical products.
- Tax percent setting applied to the overall cart purchase.
- Auto-created front-end Shop page powered by `[devone_shop]`.
- Responsive product card grid with thumbnail, name, price, description, option dropdown, and Add to Cart.
- Cart icon injected into the front-end navigation with a live item-count badge.
- Cart modal/drawer with item quantity controls, remove behavior, subtotal, tax, shipping, and total.
- Checkout fields for customer name, email, phone, and billing/shipping address.
- Test/manual checkout mode for validating orders without a payment gateway.
- Stripe Payment Element support using test/live keys.
- PayPal JavaScript SDK + Orders API support using sandbox/live credentials.
- Orders saved inside DevOneCMS with customer details, purchased items, options, totals, gateway, status, and payment reference.
- Accordion-style Orders admin screen for reviewing full order details.
- Receipt email attempt after successful checkout when server mail is configured.

## Payment security

DevOne Commerce does not store card numbers, CVV, or raw payment information. Stripe and PayPal collect sensitive payment data. DevOne Commerce stores the order record, customer details, cart details, totals, gateway used, status, and the payment reference returned by the gateway.

## Gateway modes

The plugin supports:

- Test / Manual Checkout
- Stripe Only
- PayPal Only
- Stripe + PayPal

Payment environment can be toggled between:

- Test / Sandbox
- Live / Production

## Install

1. Upload the plugin ZIP through **Admin → Plugins**.
2. Leave the folder name field blank.
3. DevOneCMS should install the plugin to `content/plugins/devone-commerce/`.
4. Activate **DevOne Commerce**.
5. Go to **Commerce → Commerce Settings**.
6. Set tax, currency, gateway display, and Test/Live credentials.
7. Visit the Shop page and run checkout tests.

## Notes

On local XAMPP test servers, receipt emails may fail unless PHP mail or SMTP is configured. This does not mean the order failed. The order is still saved inside DevOne Commerce.
